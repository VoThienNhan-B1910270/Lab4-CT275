<?php

define('BASE_URL_PATH', '/');

require_once __DIR__ . '/src/library.php';
